# Excel File Transfer for Render

## Deploy
1. Extract this ZIP and push all files to a GitHub repository.
2. In Render, create a Blueprint and select the repository. `render.yaml` defines the web service and 1 GB persistent disk.
3. After deploy completes, open the assigned HTTPS URL.
4. Upload a non-sensitive test Excel file and verify download from another device.

## Storage
`UPLOAD_DIR=/var/data/uploads` is under the Render persistent disk mounted at `/var/data`.

## Security
This starter does NOT include authentication. Add authentication/access control before placing confidential or company files on an internet-facing service. Follow your organization's security policy.
